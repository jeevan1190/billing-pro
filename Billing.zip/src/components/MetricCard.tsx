import { cn } from '@/lib/utils';

interface MetricCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  accent?: 'primary' | 'success' | 'warning' | 'destructive';
  delay?: number;
}

const accentMap = {
  primary: 'bg-primary/10 text-primary',
  success: 'bg-success/10 text-success',
  warning: 'bg-warning/10 text-warning',
  destructive: 'bg-destructive/10 text-destructive',
};

export default function MetricCard({ title, value, icon, accent = 'primary', delay = 0 }: MetricCardProps) {
  return (
    <div
      className="bg-card rounded-xl border border-border/50 p-5 shadow-card hover:shadow-card-hover transition-shadow animate-fade-up"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-muted-foreground mb-1">{title}</p>
          <p className="text-2xl font-bold tracking-tight text-card-foreground">{value}</p>
        </div>
        <div className={cn('w-10 h-10 rounded-xl flex items-center justify-center', accentMap[accent])}>
          {icon}
        </div>
      </div>
    </div>
  );
}
