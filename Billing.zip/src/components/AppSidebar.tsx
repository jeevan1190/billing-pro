import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import {
  LayoutDashboard, History, FilePlus, FileText, CreditCard, Clock,
  BarChart3, ShoppingCart, ClipboardList, Users2, Package, Tags,
  IndianRupee, UserPlus, Settings, UserCircle, LogOut, Zap, ChevronDown,
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '@/lib/utils';

interface MenuItem {
  label: string;
  icon: React.ElementType;
  path?: string;
  children?: { label: string; icon: React.ElementType; path: string }[];
}

const menu: { section: string; items: MenuItem[] }[] = [
  {
    section: 'Main',
    items: [
      { label: 'Dashboard', icon: LayoutDashboard, path: '/' },
    ],
  },
  {
    section: 'Purchases',
    items: [
      { label: 'Purchase Entry', icon: ShoppingCart, path: '/purchase-entry' },
      { label: 'Purchase History', icon: ClipboardList, path: '/purchase-history' },
    ],
  },
  {
    section: 'Sales Module',
    items: [
      { label: 'Sales History', icon: BarChart3, path: '/sales-history' },
    ],
  },
  {
    section: 'Bills Module',
    items: [
      { label: 'Create Bill', icon: FilePlus, path: '/create-bill' },
      { label: 'All Bills', icon: FileText, path: '/all-bills' },
    ],
  },
  {
    section: 'Items Module',
    items: [
      { label: 'Manage Items', icon: Package, path: '/items' },
    ],
  },
  {
    section: 'Customers Module',
    items: [
      { label: 'Customer List', icon: Users2, path: '/customers' },
    ],
  },
  {
    section: 'System',
    items: [
      { label: 'Settings', icon: Settings, path: '/settings' },
      { label: 'User Profile', icon: UserCircle, path: '/profile' },
    ],
  },
];

export default function AppSidebar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { logout, user } = useAuth();
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const toggleSection = (section: string) => {
    setCollapsed(prev => ({ ...prev, [section]: !prev[section] }));
  };

  return (
    <aside className="w-[250px] min-h-screen bg-sidebar flex flex-col border-r border-sidebar-border no-print shrink-0">
      {/* Logo */}
      <div className="h-16 flex items-center gap-3 px-5 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-lg bg-sidebar-primary/20 flex items-center justify-center">
          <Zap className="w-4 h-4 text-sidebar-primary" />
        </div>
        <span className="font-bold text-sidebar-accent-foreground tracking-tight">PhotoBill Pro</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-5">
        {menu.map(group => (
          <div key={group.section}>
            <button
              onClick={() => toggleSection(group.section)}
              className="flex items-center justify-between w-full px-2 mb-1"
            >
              <span className="text-[11px] font-semibold uppercase tracking-widest text-sidebar-muted">
                {group.section}
              </span>
              <ChevronDown className={cn(
                "w-3 h-3 text-sidebar-muted transition-transform",
                collapsed[group.section] && "-rotate-90"
              )} />
            </button>
            {!collapsed[group.section] && (
              <ul className="space-y-0.5">
                {group.items.map(item => {
                  const active = location.pathname === item.path;
                  return (
                    <li key={item.label}>
                      <button
                        onClick={() => item.path && navigate(item.path)}
                        className={cn(
                          "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                          active
                            ? "bg-sidebar-primary/15 text-sidebar-primary font-medium"
                            : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                        )}
                      >
                        <item.icon className="w-4 h-4 shrink-0" />
                        <span>{item.label}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        ))}
      </nav>

      {/* User / Logout */}
      <div className="p-3 border-t border-sidebar-border">
        <div className="flex items-center gap-3 px-3 py-2 mb-1">
          <div className="w-8 h-8 rounded-full bg-sidebar-primary/20 flex items-center justify-center text-xs font-semibold text-sidebar-primary">
            {user?.name?.[0] ?? 'A'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-sidebar-accent-foreground truncate">{user?.name}</p>
            <p className="text-xs text-sidebar-muted">Admin</p>
          </div>
        </div>
        <button
          onClick={logout}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-sidebar-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}
