import { type Invoice } from '@/contexts/InvoiceContext';
import { X, Printer, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

const fmt = (n: number) => '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: 2 });

interface Props {
  invoice: Invoice;
  onClose: () => void;
}

export default function InvoicePreview({ invoice, onClose }: Props) {
  const handlePrint = () => window.print();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-card rounded-2xl shadow-elevated w-full max-w-2xl max-h-[90vh] overflow-y-auto m-4 animate-scale-in" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-border/50">
          <div className="flex items-center gap-3">
            <h2 className="font-semibold text-card-foreground">Invoice Preview</h2>
            <span className={cn(
              'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium uppercase tracking-wider',
              invoice.paymentStatus === 'paid' ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
            )}>
              {invoice.paymentStatus}
            </span>
          </div>
          <div className="flex gap-2">
            <button onClick={handlePrint} className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
              <Printer className="w-4 h-4" />
            </button>
            <button onClick={onClose} className="p-2 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Invoice Body */}
        <div className="p-6 space-y-6 print-only">
          {/* Company Header */}
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Zap className="w-4 h-4 text-primary" />
              </div>
              <div>
                <h3 className="font-bold text-card-foreground">PhotoBill Pro</h3>
                <p className="text-xs text-muted-foreground">Professional Billing</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-bold text-lg text-card-foreground">{invoice.invoiceNumber}</p>
              <p className="text-sm text-muted-foreground">{invoice.createdAt}</p>
              <span className={cn(
                'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mt-1 uppercase tracking-wider',
                invoice.paymentStatus === 'paid' ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
              )}>
                {invoice.paymentStatus}
              </span>
            </div>
          </div>

          <div className="bg-muted/50 rounded-lg p-5">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Bill To</p>
            <p className="font-medium text-lg text-card-foreground">{invoice.customerName}</p>
            {invoice.customerPhone && <p className="text-sm text-muted-foreground mt-1">{invoice.customerPhone}</p>}
            {invoice.customerEmail && <p className="text-sm text-muted-foreground">{invoice.customerEmail}</p>}
          </div>

          {/* Items Table */}
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 font-medium text-muted-foreground">Item</th>
                <th className="text-center py-2 font-medium text-muted-foreground">Qty</th>
                <th className="text-right py-2 font-medium text-muted-foreground">Price</th>
                <th className="text-right py-2 font-medium text-muted-foreground">Total</th>
              </tr>
            </thead>
            <tbody>
              {invoice.items.map((item, i) => (
                <tr key={i} className="border-b border-border/30">
                  <td className="py-2 text-card-foreground">{item.name}</td>
                  <td className="py-2 text-center tabular-nums">{item.quantity}</td>
                  <td className="py-2 text-right tabular-nums">{fmt(item.price)}</td>
                  <td className="py-2 text-right font-medium tabular-nums">{fmt(item.quantity * item.price)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totals */}
          <div className="border-t border-border pt-4 space-y-1.5 text-sm">
            <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span className="tabular-nums">{fmt(invoice.subtotal)}</span></div>
            <div className="flex justify-between text-muted-foreground"><span>Discount (20%)</span><span className="tabular-nums">-{fmt(invoice.discount)}</span></div>
            <div className="flex justify-between text-muted-foreground"><span>Taxable Amount</span><span className="tabular-nums">{fmt(invoice.taxableAmount)}</span></div>
            {invoice.gstEnabled && <div className="flex justify-between text-muted-foreground"><span>GST (18%)</span><span className="tabular-nums">{fmt(invoice.gstAmount)}</span></div>}
            <div className="flex justify-between font-bold text-lg text-card-foreground pt-2 border-t border-border">
              <span>Total</span><span className="tabular-nums">{fmt(invoice.totalAmount)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
