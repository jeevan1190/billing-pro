import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { InvoiceProvider } from "@/contexts/InvoiceContext";
import { PurchaseProvider } from "./contexts/PurchaseContext";
import { ItemProvider } from "./contexts/ItemContext";
import { CustomerProvider } from "./contexts/CustomerContext";
import ProtectedRoute from "@/components/ProtectedRoute";
import AppLayout from "@/components/AppLayout";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import CreateBill from "./pages/CreateBill";
import SalesHistory from "./pages/SalesHistory";
import AllBills from "./pages/AllBills";
import PurchaseEntry from "./pages/PurchaseEntry";
import PurchaseHistory from "./pages/PurchaseHistory";
import ManageItems from "./pages/ManageItems";
import CustomerList from "./pages/CustomerList";
import PlaceholderPage from "./pages/PlaceholderPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function ProtectedLayout({ children }: { children: React.ReactNode }) {
  return (
    <ProtectedRoute>
      <AppLayout>{children}</AppLayout>
    </ProtectedRoute>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <InvoiceProvider>
        <PurchaseProvider>
        <ItemProvider>
        <CustomerProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/" element={<ProtectedLayout><Dashboard /></ProtectedLayout>} />
              <Route path="/create-bill" element={<ProtectedLayout><CreateBill /></ProtectedLayout>} />
              <Route path="/sales-history" element={<ProtectedLayout><SalesHistory /></ProtectedLayout>} />
              <Route path="/all-bills" element={<ProtectedLayout><AllBills /></ProtectedLayout>} />
              <Route path="/purchase-entry" element={<ProtectedLayout><PurchaseEntry /></ProtectedLayout>} />
              <Route path="/purchase-history" element={<ProtectedLayout><PurchaseHistory /></ProtectedLayout>} />
              <Route path="/items" element={<ProtectedLayout><ManageItems /></ProtectedLayout>} />
              <Route path="/customers" element={<ProtectedLayout><CustomerList /></ProtectedLayout>} />
              
              <Route path="/reports" element={<ProtectedLayout><PlaceholderPage title="Payment Reports" /></ProtectedLayout>} />
              <Route path="/suppliers" element={<ProtectedLayout><PlaceholderPage title="Suppliers" /></ProtectedLayout>} />
              <Route path="/stock" element={<ProtectedLayout><PlaceholderPage title="Manage Stock" /></ProtectedLayout>} />
              <Route path="/categories" element={<ProtectedLayout><PlaceholderPage title="Categories" /></ProtectedLayout>} />
              <Route path="/pricing" element={<ProtectedLayout><PlaceholderPage title="Pricing Setup" /></ProtectedLayout>} />
              <Route path="/add-customer" element={<ProtectedLayout><PlaceholderPage title="Add Customer" /></ProtectedLayout>} />
              <Route path="/settings" element={<ProtectedLayout><PlaceholderPage title="Settings" /></ProtectedLayout>} />
              <Route path="/profile" element={<ProtectedLayout><PlaceholderPage title="User Profile" /></ProtectedLayout>} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </CustomerProvider>
        </ItemProvider>
        </PurchaseProvider>
      </InvoiceProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
