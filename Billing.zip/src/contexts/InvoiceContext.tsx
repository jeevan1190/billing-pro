import React, { createContext, useContext, useState, useCallback } from 'react';

export interface InvoiceItem {
  name: string;
  quantity: number;
  price: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  customerName: string;
  customerPhone?: string;
  customerEmail?: string;
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  taxableAmount: number;
  gstEnabled: boolean;
  gstAmount: number;
  totalAmount: number;
  paymentStatus: 'paid' | 'unpaid';
  createdAt: string;
}

interface InvoiceContextType {
  invoices: Invoice[];
  addInvoice: (invoice: Invoice) => void;
  updateInvoiceStatus: (id: string, status: 'paid' | 'unpaid') => void;
  deleteInvoice: (id: string) => void;
  totalRevenue: number;
}

const InvoiceContext = createContext<InvoiceContextType | null>(null);

const sampleInvoices: Invoice[] = [
  {
    id: '1', invoiceNumber: 'INV-001', customerName: 'Ravi Sharma',
    customerPhone: '9876543210', items: [
      { name: 'Photo Retouching', quantity: 5, price: 800 },
      { name: 'Background Removal', quantity: 10, price: 200 },
    ],
    subtotal: 6000, discount: 1200, taxableAmount: 4800, gstEnabled: true,
    gstAmount: 864, totalAmount: 5664, paymentStatus: 'paid', createdAt: '2026-03-20',
  },
  {
    id: '2', invoiceNumber: 'INV-002', customerName: 'Priya Patel',
    customerPhone: '9123456789', items: [
      { name: 'Logo Design', quantity: 1, price: 5000 },
      { name: 'Social Media Kit', quantity: 1, price: 3000 },
    ],
    subtotal: 8000, discount: 1600, taxableAmount: 6400, gstEnabled: true,
    gstAmount: 1152, totalAmount: 7552, paymentStatus: 'unpaid', createdAt: '2026-03-21',
  },
  {
    id: '3', invoiceNumber: 'INV-003', customerName: 'Amit Verma',
    items: [
      { name: 'Photo Editing Batch', quantity: 20, price: 150 },
    ],
    subtotal: 3000, discount: 600, taxableAmount: 2400, gstEnabled: false,
    gstAmount: 0, totalAmount: 2400, paymentStatus: 'paid', createdAt: '2026-03-22',
  },
  {
    id: '4', invoiceNumber: 'INV-004', customerName: 'Sneha Gupta',
    items: [
      { name: 'Banner Design', quantity: 3, price: 1500 },
      { name: 'Flyer Design', quantity: 2, price: 800 },
    ],
    subtotal: 6100, discount: 1220, taxableAmount: 4880, gstEnabled: true,
    gstAmount: 878.4, totalAmount: 5758.4, paymentStatus: 'unpaid', createdAt: '2026-03-22',
  },
];

export function InvoiceProvider({ children }: { children: React.ReactNode }) {
  const [invoices, setInvoices] = useState<Invoice[]>(sampleInvoices);

  const addInvoice = useCallback((invoice: Invoice) => {
    setInvoices(prev => [invoice, ...prev]);
  }, []);

  const updateInvoiceStatus = useCallback((id: string, status: 'paid' | 'unpaid') => {
    setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, paymentStatus: status } : inv));
  }, []);

  const deleteInvoice = useCallback((id: string) => {
    setInvoices(prev => prev.filter(inv => inv.id !== id));
  }, []);

  const totalRevenue = invoices.reduce((s, i) => s + i.totalAmount, 0);

  return (
    <InvoiceContext.Provider value={{ invoices, addInvoice, updateInvoiceStatus, deleteInvoice, totalRevenue }}>
      {children}
    </InvoiceContext.Provider>
  );
}

export function useInvoices() {
  const ctx = useContext(InvoiceContext);
  if (!ctx) throw new Error('useInvoices must be used within InvoiceProvider');
  return ctx;
}
