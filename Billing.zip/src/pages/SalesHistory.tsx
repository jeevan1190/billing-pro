import { useState } from 'react';
import { useInvoices, type Invoice } from '@/contexts/InvoiceContext';
import InvoicePreview from '@/components/InvoicePreview';
import { FileText } from 'lucide-react';
import { cn } from '@/lib/utils';

const fmt = (n: number) => '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: 0 });

export default function SalesHistory() {
  const { invoices, updateInvoiceStatus, deleteInvoice } = useInvoices();
  const [filter, setFilter] = useState<'all' | 'paid' | 'unpaid'>('all');

  const filtered = filter === 'all' ? invoices : invoices.filter(i => i.paymentStatus === filter);

  return (
    <div>
      <div className="flex items-center justify-between mb-8 animate-fade-up">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">Sales History</h1>
          <p className="text-sm text-muted-foreground mt-1">{invoices.length} total invoices in history</p>
        </div>
        <div className="flex gap-1 bg-muted rounded-lg p-1">
          {(['all', 'paid', 'unpaid'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={cn('px-3 py-1.5 rounded-md text-sm font-medium transition-colors capitalize',
                filter === f ? 'bg-card shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'
              )}
            >{f}</button>
          ))}
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border/50 shadow-card overflow-hidden animate-fade-up" style={{ animationDelay: '100ms' }}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border/50 bg-muted/20">
                <th className="text-left px-5 py-4 font-medium text-muted-foreground">Invoice #</th>
                <th className="text-left px-5 py-4 font-medium text-muted-foreground">Customer</th>
                <th className="text-right px-5 py-4 font-medium text-muted-foreground">Date</th>
                <th className="text-right px-5 py-4 font-medium text-muted-foreground">Total Amount</th>
                <th className="text-center px-5 py-4 font-medium text-muted-foreground">Payment Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(inv => (
                <tr key={inv.id} className="border-b border-border/30 last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="px-5 py-3 font-medium text-card-foreground">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-primary" />
                      {inv.invoiceNumber}
                    </div>
                  </td>
                  <td className="px-5 py-3">{inv.customerName}</td>
                  <td className="px-5 py-3 text-right text-muted-foreground tabular-nums">{inv.createdAt}</td>
                  <td className="px-5 py-3 text-right font-medium tabular-nums text-foreground">{fmt(inv.totalAmount)}</td>
                  <td className="px-5 py-3 text-center">
                    <button
                      onClick={() => updateInvoiceStatus(inv.id, inv.paymentStatus === 'paid' ? 'unpaid' : 'paid')}
                      className={cn(
                        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium cursor-pointer hover:opacity-80 transition-opacity capitalize',
                        inv.paymentStatus === 'paid' ? 'bg-success/10 text-success' : 'bg-destructive/10 text-destructive'
                      )}
                    >
                      {inv.paymentStatus}
                    </button>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-8 text-center text-muted-foreground">
                    No invoices match the selected filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
