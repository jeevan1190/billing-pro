import { useInvoices } from '@/contexts/InvoiceContext';
import { cn } from '@/lib/utils';
import { Trash2, Eye } from 'lucide-react';
import { useState } from 'react';
import InvoicePreview from '@/components/InvoicePreview';
import type { Invoice } from '@/contexts/InvoiceContext';

const fmt = (n: number) => '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: 0 });

export default function AllBills() {
  const { invoices, updateInvoiceStatus, deleteInvoice } = useInvoices();
  const [preview, setPreview] = useState<Invoice | null>(null);
  const [filter, setFilter] = useState<'all' | 'paid' | 'unpaid'>('all');

  const filtered = filter === 'all' ? invoices : invoices.filter(i => i.paymentStatus === filter);

  return (
    <div>
      <div className="flex items-center justify-between mb-8 animate-fade-up">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground">All Bills</h1>
          <p className="text-sm text-muted-foreground mt-1">Quick view and print for your generated invoices</p>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border/50 shadow-card overflow-hidden animate-fade-up" style={{ animationDelay: '100ms' }}>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border/50 bg-muted/20">
                <th className="text-left px-5 py-4 font-medium text-muted-foreground w-36">Invoice #</th>
                <th className="text-left px-5 py-4 font-medium text-muted-foreground">Customer Name</th>
                <th className="text-right px-5 py-4 font-medium text-muted-foreground">Amount</th>
                <th className="text-center px-5 py-4 font-medium text-muted-foreground w-32">Action</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map(inv => (
                <tr key={inv.id} className="border-b border-border/30 last:border-0 hover:bg-muted/30 transition-colors">
                  <td className="px-5 py-3 font-medium text-card-foreground">
                    {inv.invoiceNumber}
                  </td>
                  <td className="px-5 py-3">{inv.customerName}</td>
                  <td className="px-5 py-3 text-right font-medium tabular-nums">{fmt(inv.totalAmount)}</td>
                  <td className="px-5 py-3 text-center">
                    <button onClick={() => setPreview(inv)} className="p-1.5 rounded-md text-primary hover:bg-primary/10 transition-colors tooltip-trigger group relative outline-none flex items-center gap-1.5 px-3 mx-auto">
                      <Eye className="w-4 h-4" /> View / Print
                    </button>
                  </td>
                </tr>
              ))}
              {invoices.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-5 py-8 text-center text-muted-foreground">
                    No invoices generated yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {preview && (
        <InvoicePreview invoice={preview} onClose={() => setPreview(null)} />
      )}
    </div>
  );
}
