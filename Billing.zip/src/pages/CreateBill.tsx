import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useInvoices, type InvoiceItem, type Invoice } from '@/contexts/InvoiceContext';
import { useItems } from '@/contexts/ItemContext';
import { Plus, Trash2, FileText } from 'lucide-react';
import InvoicePreview from '@/components/InvoicePreview';
import { cn } from '@/lib/utils';

const fmt = (n: number) => '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: 2 });

export default function CreateBill() {
  const navigate = useNavigate();
  const { addInvoice, invoices } = useInvoices();
  const { items: availableItems } = useItems();

  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [previewInvoice, setPreviewInvoice] = useState<Invoice | null>(null);
  const [items, setItems] = useState<InvoiceItem[]>([{ name: '', quantity: 1, price: 0 }]);
  const [discountType, setDiscountType] = useState<'percent' | 'fixed'>('percent');
  const [discountValue, setDiscountValue] = useState(0);
  const [gstEnabled, setGstEnabled] = useState(true);
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'unpaid'>('unpaid');
  const [error, setError] = useState('');

  const updateItem = (index: number, field: keyof InvoiceItem, value: string | number) => {
    const newItems = [...items];
    newItems[index] = { ...newItems[index], [field]: value };
    setItems(newItems);
  };

  const handleItemSelect = (index: number, selectedName: string) => {
    const selectedItem = availableItems.find(i => i.itemName === selectedName);
    const newItems = [...items];
    if (selectedItem) {
      newItems[index] = { ...newItems[index], name: selectedItem.itemName, price: selectedItem.price };
    } else {
      // If "Custom Service" or an empty option is selected, clear the price
      newItems[index] = { ...newItems[index], name: selectedName, price: selectedName === 'Custom Service' ? 0 : newItems[index].price };
    }
    setItems(newItems);
  };

  const addItem = () => setItems(prev => [...prev, { name: '', quantity: 1, price: 0 }]);
  const removeItem = (index: number) => {
    if (items.length > 1) setItems(prev => prev.filter((_, i) => i !== index));
  };

  const subtotal = items.reduce((s, item) => s + (item.quantity || 0) * (item.price || 0), 0);
  const discount = discountType === 'percent' ? (subtotal * Math.max(0, discountValue)) / 100 : Math.max(0, discountValue);
  const taxableAmount = Math.max(0, subtotal - discount);
  const gstAmount = gstEnabled ? taxableAmount * 0.18 : 0;
  const totalAmount = taxableAmount + gstAmount;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!customerName.trim()) { setError('Customer name is required'); return; }
    if (items.some(i => !i.name.trim() || i.quantity <= 0 || i.price <= 0)) {
      setError('All items must have a name, quantity > 0, and price > 0'); return;
    }

    const invoiceNumber = `INV-${String(invoices.length + 1).padStart(3, '0')}`;
    const newInvoice: Invoice = {
      id: crypto.randomUUID(),
      invoiceNumber,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail.trim(),
      items,
      subtotal,
      discount,
      taxableAmount,
      gstEnabled,
      gstAmount,
      totalAmount,
      paymentStatus,
      createdAt: new Date().toISOString().split('T')[0],
    };
    addInvoice(newInvoice);
    setPreviewInvoice(newInvoice);
  };

  return (
    <div className="max-w-3xl">
      <div className="mb-8 animate-fade-up">
        <h1 className="text-2xl font-bold tracking-tight text-foreground">Create Bill</h1>
        <p className="text-sm text-muted-foreground mt-1">Generate a new invoice for your customer</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6 animate-fade-up" style={{ animationDelay: '100ms' }}>
        {/* Customer Info */}
        <div className="bg-card rounded-xl border border-border/50 shadow-card p-5 space-y-4">
          <h2 className="font-semibold text-card-foreground flex items-center gap-2">
            <FileText className="w-4 h-4 text-muted-foreground" /> Customer Details
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Customer Name *</label>
              <input
                type="text" value={customerName} onChange={e => setCustomerName(e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg border border-input bg-background/50 text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary transition-shadow"
                placeholder="Enter customer name"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Phone</label>
              <input
                type="text" value={customerPhone} onChange={e => setCustomerPhone(e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg border border-input bg-background/50 text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary transition-shadow"
                placeholder="Phone number"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-foreground mb-1.5">Email</label>
              <input
                type="email" value={customerEmail} onChange={e => setCustomerEmail(e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg border border-input bg-background/50 text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary transition-shadow"
                placeholder="Email address"
              />
            </div>
          </div>
        </div>

        {/* Items */}
        <div className="bg-card rounded-xl border border-border/50 shadow-card p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-card-foreground">Line Items</h2>
            <button type="button" onClick={addItem} className="inline-flex items-center gap-1.5 text-sm text-primary hover:opacity-80 active:scale-[0.97] transition-all">
              <Plus className="w-4 h-4" /> Add Item
            </button>
          </div>

          <div className="space-y-3">
            {items.map((item, idx) => (
              <div key={idx} className="grid grid-cols-[1fr_80px_100px_36px] gap-3 items-end">
                <div>
                  {idx === 0 && <label className="block text-xs font-medium text-muted-foreground mb-1">Item Name</label>}
                  <div>
                    <select 
                      value={item.name} 
                      onChange={e => handleItemSelect(idx, e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-input bg-background/50 focus:outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary text-sm transition-shadow"
                    >
                      <option value="" disabled>Select a service</option>
                      {availableItems.map(ai => (
                        <option key={ai.id} value={ai.itemName}>{ai.itemName}</option>
                      ))}
                      <option value="Custom Service">Custom Service</option>
                    </select>
                    {item.name === 'Custom Service' && (
                      <input type="text" value={item.name === 'Custom Service' ? '' : item.name} onChange={e => updateItem(idx, 'name', e.target.value)}
                        className="w-full px-3 py-2 mt-2 rounded-lg border border-input bg-background/50 focus:outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary text-sm transition-shadow"
                        placeholder="Describe custom service" />
                    )}
                  </div>
                </div>
                <div>
                  {idx === 0 && <label className="block text-xs font-medium text-muted-foreground mb-1">Qty</label>}
                  <input
                    type="number" min={1} value={item.quantity} onChange={e => updateItem(idx, 'quantity', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground text-sm tabular-nums focus:outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary transition-shadow"
                  />
                </div>
                <div>
                  {idx === 0 && <label className="block text-xs font-medium text-muted-foreground mb-1">Price (₹)</label>}
                  <input
                    type="number" min={0} value={item.price} onChange={e => updateItem(idx, 'price', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-input bg-background text-foreground text-sm tabular-nums focus:outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary transition-shadow"
                  />
                </div>
                <button type="button" onClick={() => removeItem(idx)}
                  className="h-[38px] w-9 flex items-center justify-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors active:scale-95"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card rounded-xl border border-border/50 shadow-card p-5">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div className="flex-1 space-y-4">
              <h3 className="font-semibold text-card-foreground">Adjustments</h3>
              <div className="flex items-center gap-4">
                <div className="flex flex-col gap-1.5 flex-1 max-w-[200px]">
                  <label className="text-sm font-medium text-muted-foreground">Discount</label>
                  <div className="flex rounded-lg overflow-hidden border border-input focus-within:ring-2 focus-within:ring-ring/20 focus-within:border-primary">
                    <select 
                      value={discountType} 
                      onChange={e => setDiscountType(e.target.value as 'percent' | 'fixed')}
                      className="bg-muted/50 px-2.5 py-2 text-sm text-foreground outline-none border-r border-input"
                    >
                      <option value="percent">%</option>
                      <option value="fixed">₹</option>
                    </select>
                    <input 
                      type="number" min={0} value={discountValue || ''} onChange={e => setDiscountValue(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-background/50 text-sm outline-none tabular-nums"
                      placeholder="0"
                    />
                  </div>
                </div>
              </div>
              
              <label className="inline-flex items-center gap-2 text-sm mt-3 cursor-pointer">
                <input type="checkbox" checked={gstEnabled} onChange={e => setGstEnabled(e.target.checked)}
                  className="rounded border-input text-primary focus:ring-primary w-4 h-4 cursor-pointer" />
                <span className="font-medium">Apply GST (18%)</span>
              </label>

              <div className="flex flex-col gap-1.5 flex-1 max-w-[200px] mt-2">
                <label className="text-sm font-medium text-muted-foreground">Payment Status</label>
                <select value={paymentStatus} onChange={e => setPaymentStatus(e.target.value as 'paid' | 'unpaid')}
                  className="w-full px-3 py-2 rounded-lg border border-input bg-background/50 text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-ring/20 focus:border-primary transition-shadow capitalize"
                >
                  <option value="unpaid">Unpaid</option>
                  <option value="paid">Paid</option>
                </select>
              </div>
            </div>

            <div className="border-t md:border-t-0 md:border-l border-border/50 pt-4 md:pt-0 md:pl-6 min-w-[250px] space-y-3 text-sm">
              <div className="flex justify-between text-muted-foreground"><span>Subtotal</span><span className="tabular-nums font-medium text-foreground">{fmt(subtotal)}</span></div>
              {discount > 0 && <div className="flex justify-between text-muted-foreground"><span>Discount</span><span className="tabular-nums text-success">-{fmt(discount)}</span></div>}
              <div className="flex justify-between text-muted-foreground"><span>Taxable Amount</span><span className="tabular-nums">{fmt(taxableAmount)}</span></div>
              {gstEnabled && <div className="flex justify-between text-muted-foreground"><span>GST (18%)</span><span className="tabular-nums">{fmt(gstAmount)}</span></div>}
              <div className="flex justify-between font-bold text-xl text-primary pt-3 border-t border-border/50">
                <span>Total Amount</span><span className="tabular-nums tracking-tight">{fmt(totalAmount)}</span>
              </div>
            </div>
          </div>
        </div>

        {error && <p className="text-sm text-destructive animate-fade-in">{error}</p>}

        <div className="flex items-center justify-end">
          <button type="submit"
            className="px-8 py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:opacity-90 hover:scale-[1.02] active:scale-[0.98] transition-all shadow-lg shadow-primary/20 flex items-center gap-2"
          >
            <FileText className="w-4 h-4" />
            Generate Invoice
          </button>
        </div>
      </form>

      {previewInvoice && (
        <InvoicePreview 
          invoice={previewInvoice} 
          onClose={() => {
            setPreviewInvoice(null);
            navigate('/sales-history');
          }} 
        />
      )}
    </div>
  );
}
